# Dashboard Indeks Standar Pencemar Udara (ISPU)

## Setup Environment - Anaconda
```
conda create --name main-ds python=3.11
conda activate main-ds
```

## Setup Environment - Shell/Terminal
```
mkdir dashboard_project
cd dashboard_project
```
## Run steamlit app
```
Run steamlit app
```
